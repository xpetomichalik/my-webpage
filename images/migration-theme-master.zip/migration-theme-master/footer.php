<?php
/**
 * The template for displaying the footer.
 */
?>

<?php wp_footer(); ?>

</body>
</html>