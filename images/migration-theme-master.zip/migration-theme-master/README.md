Migration Theme for WordPress
===============

There's not much to it! This theme is meant as a simple starting point for your next migration to WordPress.

Note that this theme does not have "blogging" templates included. 

If you need blog functionality, you can take a look at Twenty Twelve (http://wordpress.org/extend/themes/twentytwelve) 
or other WordPress themes to see how to add in the basic blog templates.
